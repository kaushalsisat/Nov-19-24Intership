
// 2.Default Export:
// In a file greeting.js, export a default function greet(name) that returns a
//  greeting message. Import this function in app.js and use it to greet a user.

function greet(name){
    return "Hello, ${name}! Welcome!";
}

export default greet;
//output
//  Hello, kaushal! Welcome!