import greet from './greeting.js';


const message = greet('kaushal');
console.log(message);