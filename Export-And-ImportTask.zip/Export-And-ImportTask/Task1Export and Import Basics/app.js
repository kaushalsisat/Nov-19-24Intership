const math = require('./math');

const sum = math.add(6, 3);
console.log("The sum of 6 and 3 is: ",{sum});

const subtract = math.sub(6, 3);
console.log("The subtract between 6 and 3 is: ",{subtract});

 


