// 1.Export and Import Basics:
// Create a file math.js that exports two functions, add(a, b) and subtract(a, b). Create another file app.js
// that imports these functions and uses them to add and subtract two numbers.


function add(a,b){
    return a + b;    
}
   
  
function sub(a,b){
    return a - b;
}
// Export the functions
module.exports = {
    add,
    sub
};

// The sum of 5 and 3 is:  { sum: 9 }
// The subtract between 6 and 3 is:  { subtract: 3 }








