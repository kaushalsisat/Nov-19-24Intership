
import { setUser, getUser } from './user.js';

setUser('kaushal');

// Use the getUser function to retrieve the user's name
const name = getUser();
console.log(`The user's name is: ${name}`);










