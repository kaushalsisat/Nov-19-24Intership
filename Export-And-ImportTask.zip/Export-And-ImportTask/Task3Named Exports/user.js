// 3.Named Exports:
// Create a file user.js that exports two named functions, 
// getUser(name) and setUser(name). Import these functions in 
// app.js and use them to set and get a user's name.

let userName = '';

function setUser(name) {
     userName = name;
}

function getUser(name){
    return userName;

}
export{setUser,getUser};


