import React from 'react'

const Article = () => {
  return (
    <div className='bg-orange-500 m-4 grid items-center justify-center h-16'>
      Article
    </div>
  )
}

export default Article
