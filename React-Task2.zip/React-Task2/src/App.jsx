import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import Header from "./Header"
import Nav from "./Nav"
import Section from "./Section"
import Article from "./Article"
import Aside from "./Aside"
import Footer from "./Footer"

function App() {
  const [count, setCount] = useState(0)

  return (
    <>
    <div className='border border-black w-[600px] ml-64 mt-6'>
       <div><Header/></div>
       <div><Nav/></div>

       <div className='grid grid-cols-12'>
          <div className='col-span-8'>
          <div className=''><Section/></div>
          <div className=''><Article/></div>
          </div>
          <div className='col-span-4'><Aside/></div> 
       </div>

        <div><Footer/></div>
    </div>
    </>
  )
}

export default App
