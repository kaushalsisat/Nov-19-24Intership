
import React from 'react'

const Nav = () => {
  return (
    <div className='flex justify-center items-center h-12 bg-blue-500 m-4'>
      Nav
    </div>
  )
}

export default Nav
