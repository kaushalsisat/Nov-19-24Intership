import React from 'react'

const Section = () => {
  return (
    <div className='grid justify-center items-center h-16 bg-yellow-500 ml-4 mr-4 mt-2 mb-4'>
       Section
    </div>
  )
}

export default Section
