import React from 'react'

const Aside = () => {
  return (
    <div className='bg-pink-500 ml-4 mr-4 mt-2 mb-4 grid items-center justify-center h-36 p-8'>
      Aside
    </div>
  )
}

export default Aside
