import React from 'react'

const Header = () => {
  return (
    <div className='bg-red-600 text-center m-4 h-12 flex justify-center items-center'>
      Header
    </div>
  )
}

export default Header
