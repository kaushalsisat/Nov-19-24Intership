import React from 'react'

const Footer = () => {
  return (
    <div className='bg-slate-500 text-white text-center ml-4 mr-4 mt-2 mb-4 h-12 flex justify-center items-center'>
      Footer
    </div>
  )
}

export default Footer
