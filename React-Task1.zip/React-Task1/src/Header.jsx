import React from 'react'

const Header = () => {
  return (
    <div className='bg-blue-300 h-16 text-white flex justify-center items-center'>
      Header
    </div>
   
  )
}

export default Header
