import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import Header from "./Header"
import Aside from "./Aside"
import Article from "./Article"
import Footer from "./Footer"


function App() {
  const [count, setCount] = useState(0)

  return (
    <>
      <div>

      <div className='mt-6 mb-6 ml-24 mr-24'>
      <Header/>
      </div>

      <div className='grid grid-cols-12 gap-4 mt-6 mb-6 ml-24 mr-24 h-[410px] text-white'>
      <div className='grid col-span-3'><Aside/></div>
      <div className='grid col-span-9'><Article/></div>
      </div>

      <div className='mt-6 mb-6 ml-24 mr-24 text-white'>
      <Footer/>
      </div>

      </div>
    </>
  )
}

export default App
