import React from 'react'

const Footer = () => {
  return (
    <div className='bg-blue-300 h-16 text-white flex justify-center items-center'>
      Footer
    </div>
  )
}

export default Footer
