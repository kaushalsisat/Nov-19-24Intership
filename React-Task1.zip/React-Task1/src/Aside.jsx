import React from 'react'

const Aside = () => {
  return (
    <div className='bg-blue-700 grid justify-center items-center'>
      Aside
    </div>
  )
}

export default Aside
