import React from 'react'

const Article = () => {
  return (
    <div className='bg-red-500 grid justify-center items-center text-center'>
      Article
      <div className='flex gap-20'>
      <div className='bg-slate-400 h-[200px] w-[200px] grid justify-center items-center'>Image</div>
      <div className='bg-slate-400 h-[200px] w-[200px] grid justify-center items-center'>Image</div>
      <div className='bg-slate-400 h-[200px] w-[200px] grid justify-center items-center'>Image</div>
      </div>
    </div>
  )
}

export default Article
